ActiveAdmin.register SmtpSetting do
   #menu :parent => "Setting", :url => "/admin/site_settings/fb_settings" ,:priority => 2
   menu false
  config.clear_sidebar_sections! 
  config.clear_action_items!
  
 controller do
   def index
  #  render :text=> "Hello" and return
      redirect_to("/admin/smtp_settings/1/edit" )
   end
   
   def update
      update! do 
         redirect_to("/admin/smtp_settings/1/edit" ) and return
      end
   end
 end
  
  form do |f|
      f.inputs "Smtp Setting" do
  		f.input :id
  		f.input :host
  		f.input :domain
  		f.input :authentication
  		f.input :username
  		f.input :password
	  end
    
       f.buttons do
	     f.action(:submit) 
       end
    end
end