ActiveAdmin.register TicketStatus do
  menu false
end
