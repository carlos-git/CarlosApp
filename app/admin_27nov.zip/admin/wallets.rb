ActiveAdmin.register Wallet do
  config.sort_order = "id_desc"
  menu false
  #menu :parent => "Wallet" ,:priority => 2, :label => "Confirm Withdrawals"
  actions :all, :except => [:new]
  
   config.batch_actions = false
   config.clear_action_items!
   config.filters = false
   
   controller do
     def details
     
      @page_title = "Withdrawal Details"
            
      if params[:id]
         @with = WalletWithdraw.find(params[:id])
         @with_detail = WalletTransactionDetail.find(:first, :conditions => ["wallet_withdraw_id = ?", @with[:id]]) 
       end
       
       render "details" , :layout => 'active_admin'
     end
   end 
   
   
   index :title => 'Confirmed Withdrawals'+SiteSetting.site_title do 
     render "index" , :layout => 'active_admin'
   end
   
   
end