ActiveAdmin.register EventRepeat do
  menu false
end
