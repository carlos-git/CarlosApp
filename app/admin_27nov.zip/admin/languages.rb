ActiveAdmin.register Language do
   #menu :parent => "Setting",:priority => 8
   menu false
end
