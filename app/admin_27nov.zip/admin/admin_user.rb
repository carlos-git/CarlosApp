ActiveAdmin.register AdminUser do     
  #menu :priority => 2
  menu false
  
  
  
  index :title => 'Admin Users'+SiteSetting.site_title do                          
    column :email 
                       
    column 'Current Login', :current_sign_in_at        
    column 'Last Login', :last_sign_in_at           
    column 'Login count', :sign_in_count             
    #current_admin_user[:id]
    @count = AdminUser.count
   if @count == 1
      column do |show|
        links = link_to 'View', {:action => show.id.to_s}
        links += ' '
        links += link_to 'Edit', {:action => show.id.to_s+'/edit'}
        links
      end  
   else
     default_actions
   end  
  
                      
  end                                 

  controller do
    def password
     
    end
    
     def new
           @admin_user = AdminUser.new
      end
      

      def create
      
         # @temp = params[:admin_user][:role_permission]
         # if @temp ==nil
               
         # else
         #   @new_per = @temp.join(',') 
          #  params[:admin_user][:role_permission] = @new_per 
         # end
          
         @admin_user = AdminUser.new(params[:admin_user])
         @admin_user.save
         redirect_to(:action => 'index')
       end

       def edit
        @admin_user = AdminUser.find(params[:id])
      end
    
  end
  
  filter :email                       

  sidebar :AdminUserRights do
      ul do
        li "Super Admin: Can Manage All Pages"
        li "Sub Admin: Can Only View And Update All Pages"
        li "Normal Admin: Can Only View All Pages"
        li "Custom Admin: Customize your admin via giving them custom rights of links"
      end
    end

	
	form :html => { :enctype => "multipart/form-data" } do |f|
        	render "create" , :layout => 'active_admin'
        end  

=begin
  form do |f|                         
    f.inputs "Admin Details" do       
      f.input :email                  
      f.input :password               
      f.input :password_confirmation
      f.input :role ,:as => :select ,:include_blank => false, :collection => ["superadmin","subadmin","normaladmin"]
    end                               
    f.actions                         
  end 
=end
                                
end                                   